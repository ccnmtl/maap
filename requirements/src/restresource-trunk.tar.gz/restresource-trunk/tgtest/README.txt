tgtest

This is a TurboGears (http://www.turbogears.org) project. It can be
started by running the start-tgtest.py script.

Test restresource by running in this directory:
# nosetests -w tgtest/tests