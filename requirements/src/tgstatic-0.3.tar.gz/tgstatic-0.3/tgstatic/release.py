version = "0.3"
author = "anders pearson"
email = "anders@columbia.edu"
description = "static publishing helper for turbogears"
