from setuptools import setup, find_packages

import os
execfile(os.path.join("tgstatic", "release.py"))

setup(
    name="tgstatic",
    version=version,

    # uncomment the following lines if you fill them out in release.py
    #description=description,
    #author=author,
    #author_email=email,
    #url=url,
    #download_url=download_url,
    #license=license,

    install_requires = [
        "TurboGears >= 1.0b1",
    ],
    scripts = [],
    zip_safe=False,
    packages=find_packages(),
    keywords = [
    ],
    classifiers = [
        'Development Status :: 3 - Alpha',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Framework :: TurboGears',
    ],
    test_suite = 'nose.collector',
    )
